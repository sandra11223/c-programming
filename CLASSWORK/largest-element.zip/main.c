/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[]={2,4,9,13};
    int n = sizeof(arr[0]);
    int max=arr[0];
    for(int i=1;i<n;i++)
    {
     if(arr[i]>max)max=arr[i];
    }
    printf("largest element %d",max);
    return 0;
}