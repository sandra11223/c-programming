/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

  int findLargest(int a,int b,int c)
  {
  int max = a;

    if(b > max) 
    {
        max = b;
    }
    if(c > max) 
    {
        max = c;
    }

    return max;
   }


int main()
{
    int num1,num2,num3;
    printf("enter 3 numbers:");
    scanf("%d%d%d",&num1,&num2,&num3);
    int largest=findLargest(num1,num2,num3);
    printf("the largest number is %d\n",largest);
    
   return 0;
}
