/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int customerID;
    char name[50];
    float units, totalAmount;

    printf("Enter Customer ID: ");
    scanf("%d", &customerID);

    printf("Enter Customer Name: ");
    scanf("%c", name);  

    printf("Enter units consumed: ");
    scanf("%f", &units);

    if (units <= 199)
        totalAmount = units * 1.20;
    else if (units >= 200 && units < 400)
        totalAmount = units * 1.50;
    else if (units >= 400 && units < 600)
        totalAmount = units * 1.80;
    else
        totalAmount = units * 2.00;

    if (totalAmount < 100)
        totalAmount = 100;   

    printf("\nElectricity Bill\n");
    printf("----------------------------\n");
    printf("Customer ID   : %d\n", customerID);
    printf("Customer Name : %s\n", name);
    printf("Units Consumed: %.2f\n", units);
    printf("Total Amount  : ₹%.2f\n", totalAmount);
    printf("----------------------------\n");

    return 0;
}
