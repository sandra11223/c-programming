/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char str[100];
    int vowels=0,consonants=0,i;
    printf("enter the string:");
    scanf("%s",str);
    for(i=0;str[i]!='\0';i++)
    {
        char ch=str[i];
            if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U')
            vowels++;
        else
        {
            consonants++;
        }
    }
        printf("vowels:%d\n",vowels);
        printf("consonants:%d\n",consonants);
        
    return 0;
}
    
    
