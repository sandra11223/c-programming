/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main()
   {
       char str[100],str2[100]; 
       printf("enter the  first string");
       scanf("%s",str2);
       printf("enter the second string");
       scanf("%s",str2);
       printf("length of first string:%lu\n",strlen(str));
       printf("length of second string:%lu\n",strlen(str2));
       strcat(str,str2);
       printf("concatenation:%s\n",str);
       printf("%d\n",strcmp(str,str2));
       strcpy(str2,str);
       printf("copied:%s\n",str2);
  return 0;
       
   }
    
    
       
       
