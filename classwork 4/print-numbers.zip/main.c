/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void printnumbers(int x);
void printnumbers(int x)
{
    if(x>0)
    {
        printnumbers(x-1);
        printf("%d\n",x);
    }
}
int main()
{
    int a;
    printf("enter the limit:");
    scanf("%d",&a);
    printnumbers(a);
}