/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

    void sortstring(char str[]) {
    int i, j;
    char temp;
    int len = strlen(str);
    for (i = 0; i < len - 1; i++) {
        for (j = i + 1; j < len; j++) {
            if (str[i] > str[j]) {
                temp = str[i];
                str[i] = str[j];
                str[j] = temp;
            }
        }
    }
}
 int main()
 {
     char str1[100],str2[100];
     printf("enter the first string");
     scanf("%s",str1);
     printf("enter the second string");
     scanf("%s",str2);
     if(strlen(str1)!=strlen(str2))
     {
         printf("the string is not anagram");
     }
     sortstring(str1);
     sortstring(str2);
      
      if (strcmp(str1, str2) == 0) {
        printf("The strings are anagrams.\n");
    } else {
        printf("The strings are not anagrams.\n");
    }

    return 0;
}
     
    